python3 /root/Astockdem/Doubesemble_test.py -l 5 
