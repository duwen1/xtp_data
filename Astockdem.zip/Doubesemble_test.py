import pandas as pd
import numpy as np
import xgboost as xgb
from xgboost import XGBRegressor, XGBRanker
from shutil import copyfile
import time,datetime
from redis_client import redis_client
import string

def load_contract():
    contract_dict = {}
    with open('/root/pair_market/cfg_all.txt', "r") as f:
        for line in f.readlines():
            line = line.strip('\n')  #去掉列表中每一个元素的换行符
            if 'contract' in line:
                comd = line.split('=')[1].strip(string.digits)
                contract_dict[comd] = line.split('=')[1]
    return contract_dict


class DEnsembleModel(object):

    def __init__(self, path_close, path_open, path_max, path_min, path_mny,path_idct,
                 base_model="gbm",
                 loss="mse",
                 num_models=6,
                 enable_sr=True,
                 enable_fs=True,
                 alpha1=1.0,
                 alpha2=1.0,
                 bins_sr=10,
                 bins_fs=5,
                 decay=0.5,
                 sample_ratios=None,
                 sub_weights=None,
                 epochs=200):
                 

        self.path_mny=path_mny
        self.close = pd.read_csv(path_close, index_col=0).drop(
            columns=['date'])
        self.open = pd.read_csv(path_open, index_col=0).drop(
            columns=['date'])
        self.max = pd.read_csv(path_max, index_col=0).drop(
            columns=['date'])
        self.min = pd.read_csv(path_min, index_col=0).drop(
            columns=['date'])
        # self.label = (self.close - self.open) / self.open

        self.alpha_feature = np.load(path_idct)[:,:,:-3]
        # self.alpha_feature = np.load('/media/group2/dhk/fgs/alpha_1-6vol.npy')
        self.alpha_feature[np.isneginf(self.alpha_feature)] = 0
        self.alpha_feature[np.isinf(self.alpha_feature)] = 0
        self.label = self.close.pct_change()
        # self.label = self.close/self.open-1
        self.base_model = base_model  # "gbm" or "mlp", specifically, we use lgbm for "gbm"
        self.num_models = num_models  # the number of sub-models
        self.enable_sr = enable_sr
        self.enable_fs = enable_fs
        self.alpha1 = alpha1
        self.alpha2 = alpha2
        self.bins_sr = bins_sr
        self.bins_fs = bins_fs
        self.decay = decay

        if sample_ratios is None:  # the default values for sample_ratios
            sample_ratios = [0.8, 0.7, 0.6, 0.5, 0.4]
        if sub_weights is None:  # the default values for sub_weights
            sub_weights = [1.0, 0.2, 0.2, 0.2, 0.2, 0.2]
            # sub_weights = [1.0]
            # sub_weights = [1.0, 0.1, 0.1, 0.1, 0.1, 0.1,0.1, 0.1, 0.1, 0.1, 0.1]

        self.sample_ratios = sample_ratios
        self.sub_weights = sub_weights
        self.epochs = epochs

        self.ensemble = []  # the current ensemble model, a list contains all the sub-models
        self.sub_features = []  # the features for each sub model in the form of pandas.Index
        self.params = {"objective": loss}
        self.loss = loss
    def fit(self,train_len, val_len):
        self.factor_preprocess(self.path_mny)

        tr_idx = (0, train_len)
        va_idx = (train_len,train_len + val_len)
        feature_raw = self.alpha_feature[:, -(train_len+val_len+1):-1, :]
        # stocknum, datalen, featurelen = feature_raw.shape
        # feature_raw = feature_raw.reshape(stocknum * datalen, featurelen)
        rate = self.label.iloc[-(train_len+val_len):, :].values
        print(feature_raw.shape, rate.shape)

        rate = rate.transpose((1, 0))

        x_train, y_train, x_test, y_test = feature_raw[:, tr_idx[0]:tr_idx[1], :], rate[:,
                                                                                   tr_idx[0]:tr_idx[1]], feature_raw[:,
                                                                                                         va_idx[0]:
                                                                                                         va_idx[1],
                                                                                                         :], rate[:,
                                                                                                             va_idx[0]:
                                                                                                             va_idx[1]]

        stocknum, datalen, featurelen = x_train.shape
        stocknum, datalen_test, featurelen = x_test.shape

        x_train = x_train.reshape(stocknum * datalen, featurelen)
        y_train = y_train.reshape(-1, 1)
        x_test = x_test.reshape(stocknum * datalen_test, featurelen)
        y_test = y_test.reshape(-1, 1)
        print(x_train.shape, y_train.shape, x_test.shape, y_test.shape)
        # print(rate)
        # print(self.open.iloc[idx[ii][1], 1:].values)
        # data_train = np.concatenate((feature_raw, rate.reshape(stocknum * datalen, 1)), axis=1)
        condition_train = (~np.isnan(x_train).any(axis=1)) & (~np.isnan(y_train).any(axis=1))
        condition_test = (~np.isnan(x_test).any(axis=1)) & (~np.isnan(y_test).any(axis=1))

        N, F = x_train[condition_train].shape

        weights = pd.Series(np.ones(N, dtype=float))

        features = np.arange(F)
        pred_sub = pd.DataFrame(np.zeros((N, self.num_models), dtype=float), index=np.arange(N))

        for k in range(self.num_models):
            self.sub_features.append(features)
            print('Training sub-model:' + str(k + 1) + '/' + str(self.num_models))
            model_k = self.train_submodel(x_train[condition_train], y_train[condition_train], x_test[condition_test],
                                          y_test[condition_test], weights, features)
            self.ensemble.append(model_k)
            model_k.save_model('/root/Astockdem/xgb_' + str(k) + '.model')
            np.save('/root/Astockdem/feature_id_' + str(k) + '.npy',features)
            if k + 1 == self.num_models:
                break

            print('Retrieving loss curve and loss values...')
            loss_curve = self.retrieve_loss_curve(model_k, x_train[condition_train], y_train[condition_train], features)
            pred_k = self.predict_sub(model_k, x_train[condition_train], y_train[condition_train], features)
            pred_sub.iloc[:, k] = pred_k
            pred_ensemble = pred_sub.iloc[:, : k + 1].mean(axis=1)

            loss_values = pd.Series(self.get_loss(y_train[condition_train], pred_ensemble))
            if self.enable_sr:
                print("Sample re-weighting...")
                weights = self.sample_reweight(loss_curve, loss_values, k + 1)

            if self.enable_fs:
                print("Feature selection...")
                features = self.feature_selection(x_train[condition_train], y_train[condition_train], loss_values)
                print('Number of select feature:' + str(len(features)))

        #return self.test_regression(start_time + train_len + val_len, test_len)
        print('Finish training!')
    def train_submodel(self, x_train, y_train, x_test, y_test, weights, features):
        # dtrain, dvalid = self._prepare_data_gbm(x_train,y_train, x_test, y_test, weights, features)
        x_train, y_train, x_test, y_test = self._prepare_data_gbm(x_train, y_train, x_test, y_test, weights, features)
        evals_result = dict()


        model = XGBRegressor(max_depth=7,
                             learning_rate=0.1,
                             n_estimators=200,
                             # objective='reg:linear', # 此默认参数与 XGBClassifier 不同
                             booster='gbtree',
                             gamma=0,
                             min_child_weight=1,
                             subsample=1,
                             colsample_bytree=1,
                             reg_alpha=0,
                             reg_lambda=1,
                             random_state=0,
                             #tree_method='gpu_hist',
                             #gpu_id=0
                             )

        model.fit(X=x_train, y=y_train, sample_weight=weights, eval_set=[(x_test, y_test)], early_stopping_rounds=50)


        return model

    def _prepare_data_gbm(self, x_train, y_train, x_test, y_test, weights, features):

        x_train = x_train[:, features]
        x_test = x_test[:, features]
        y_train = np.squeeze(y_train)
        y_test = np.squeeze(y_test)
        # dtrain = lgb.Dataset(x_train, label=y_train, weight=weights)
        # dtest = lgb.Dataset(x_test, label=y_test)

        return x_train, y_train, x_test, y_test

    def sample_reweight(self, loss_curve, loss_values, k_th):

        # normalize loss_curve and loss_values with ranking
        loss_curve_norm = loss_curve.rank(axis=0, pct=True)
        loss_values_norm = (-loss_values).rank(pct=True)

        # calculate l_start and l_end from loss_curve
        N, T = loss_curve.shape
        part = np.maximum(int(T * 0.1), 1)
        l_start = loss_curve_norm.iloc[:, :part].mean(axis=1)
        l_end = loss_curve_norm.iloc[:, -part:].mean(axis=1)

        # calculate h-value for each sample
        h1 = loss_values_norm
        h2 = (l_end / l_start).rank(pct=True)
        h = pd.DataFrame({"h_value": self.alpha1 * h1 + self.alpha2 * h2})

        # calculate weights
        h["bins"] = pd.cut(h["h_value"], self.bins_sr)
        h_avg = h.groupby("bins")["h_value"].mean()
        weights = pd.Series(np.zeros(N, dtype=float))
        for i_b, b in enumerate(h_avg.index):
            weights[h["bins"] == b] = 1.0 / (self.decay ** k_th * h_avg[i_b] + 0.1)
        return weights

    def feature_selection(self, x_train, y_train, loss_values):

        N, F = x_train.shape
        features = np.arange(F)
        g = pd.DataFrame({"g_value": np.zeros(F, dtype=float)})
        M = len(self.ensemble)

        # shuffle specific columns and calculate g-value for each feature
        x_train_tmp = x_train.copy()
        for i_f, feat in enumerate(features):
            # pred_f = pd.Series(np.zeros(N))
            # for n in range(5):
            x_train_tmp[:, feat] = np.random.permutation(x_train_tmp[:, feat])
            pred = pd.Series(np.zeros(N))
            for i_s, submodel in enumerate(self.ensemble):
                pred += (
                        pd.Series(
                            submodel.predict(x_train_tmp[:, self.sub_features[i_s]])
                        )
                        / M
                )
                # pred_f+=(1/5)*pred
            loss_feat = self.get_loss(y_train.squeeze(), pred.values)
            g.loc[i_f, "g_value"] = np.mean(loss_feat - loss_values) / (np.std(loss_feat - loss_values) + 1e-7)
            x_train_tmp[:, feat] = x_train[:, feat].copy()

        # one column in train features is all-nan # if g['g_value'].isna().any()
        g["g_value"].replace(np.nan, 0, inplace=True)

        # divide features into bins_fs bins
        g["bins"] = pd.cut(g["g_value"], self.bins_fs)

        # randomly sample features from bins to construct the new features
        res_feat = []
        sorted_bins = sorted(g["bins"].unique(), reverse=True)
        for i_b, b in enumerate(sorted_bins):
            b_feat = features[g["bins"] == b]
            num_feat = int(np.ceil(self.sample_ratios[i_b] * len(b_feat)))
            res_feat = res_feat + np.random.choice(b_feat, size=num_feat, replace=False).tolist()
        return list(set(res_feat))

    def get_loss(self, label, pred):
        if self.loss == "mse":
            mse = (np.squeeze(label) - pred) ** 2
            return mse
        else:
            raise ValueError("not implemented yet")

    def retrieve_loss_curve(self, model, x_train, y_train, features):
        if self.base_model == "gbm":
            # num_trees = model.num_trees()
            # num_trees = model.booster_.num_trees()
            num_trees = model.best_iteration

            # x_train, y_train = df_train["feature"].loc[:, features], df_train["label"]
            # Lightgbm need 1D array as its label
            x_train = x_train[:, features]
            N = x_train.shape[0]
            loss_curve = pd.DataFrame(np.zeros((N, num_trees)))
            pred_tree = np.zeros(N, dtype=float)
            for i_tree in range(num_trees):
                # print(num_trees)
                # pred_tree += model.predict(x_train, start_iteration=i_tree, num_iteration=1)
                pred_tree += model.predict(x_train, iteration_range=(i_tree, i_tree + 1))
                loss_curve.iloc[:, i_tree] = self.get_loss(y_train, pred_tree)
        else:
            raise ValueError("not implemented yet")
        return loss_curve

    def predict_sub(self, submodel, x_data, y_data, features):
        x_data = x_data[:, features]
        pred_sub = pd.Series(submodel.predict(x_data))
        return pred_sub

    def predict(self, x_test):
        #if self.ensemble is None:
        #    raise ValueError("model is not fitted yet!")
        for i in range(self.num_models):
            f=np.load('/root/Astockdem/feature_id_' + str(i) + '.npy')
            self.sub_features.append(f)
            model=XGBRegressor()
            model.load_model('/root/Astockdem/xgb_'+str(i)+'.model')
            self.ensemble.append(model)

        pred = pd.Series(np.zeros(x_test.shape[0]))
        for i_sub, submodel in enumerate(self.ensemble):
            feat_sub = self.sub_features[i_sub]
            pred += (
                    pd.Series(submodel.predict(x_test[:, feat_sub]))
                    * self.sub_weights[i_sub]
            )
        return pred

    def test_regression(self,contract_dict, long=2):
        mny = pd.read_csv(self.path_mny,index_col=0).drop(columns=['date'])
        
        row=mny.iloc[-1,:]
        q = row.quantile(0.2)
            #print(row[row > q].index)
        self.label.loc[len(self.label)-1, row[row < q].index] = np.nan
            
        feature_raw = self.alpha_feature[:, -1, :]


        # print(date)
        input = feature_raw
        name=self.close.columns.values

        condition_test = (~np.isnan(input).any(axis=1))&(~np.isnan(self.label.iloc[-1,:].values))
        name=name[condition_test]
        # print(input[condition_test].shape, label[condition_test].shape)
        pre = self.predict(input[condition_test])
        pre=np.squeeze(pre)
        order=np.argsort(pre)
        long_name=name[order][-long-2:][::-1]
        
        long_num = 0
        with open("/root/Astockdem/name.txt", "w") as f:
            f.write("Long:\n")
            for n in long_name:
                #contract_ask_price = float(redis_client.get(f"{contract_dict[n]}_ask"))
                #if contract_ask_price==0 or contract_ask_price>1000000:
                #    print(f"{contract_dict[n]}涨停，不交易")
                #else:
                f.write(n+'\n')
                long_num = long_num+1
                if long_num>=long:break

            f.close()
        print('Result is saved!')
    def time_len(self):
        return self.alpha_feature.shape[1]

    def clean_model(self):
        self.ensemble = []
        self.sub_features = []

    def factor_preprocess(self, mny_path):
        mny = pd.read_csv(mny_path,index_col=0).drop(columns=['date'])

        for i, row in mny.iterrows():
            q = row.quantile(0.2)
            #print(row[row > q].index)
            self.label.loc[i, row[row < q].index] = np.nan

        self.label[abs(self.label) >= 0.1] = np.nan

        # for factor in range(self.alpha_feature.shape[2]):
        #    self.alpha_feature[:,:,factor]=self.factor_numpy_fill(self.alpha_feature[:,:,factor])

    def factor_numpy_fill(self, arr):
        mask = np.isnan(arr)
        idx = np.where(~mask, np.arange(mask.shape[1]), 0)
        np.maximum.accumulate(idx, axis=1, out=idx)
        out = arr[np.arange(idx.shape[0])[:, None], idx]
        return out

import argparse
if __name__ == '__main__':
    contract_dict = load_contract()
    #copyfile('/root/Astockdem/name.txt', '/root/Astockdem/name_last.txt')
    #time.sleep(10)
    print(datetime.datetime.now())
    parser = argparse.ArgumentParser(allow_abbrev=False)
    parser.add_argument('-l', '--long_num', default=5,type=int)
    #parser.add_argument('-s', '--short_num', default=2, type=int)
    #parser.add_argument('-t_l', '--train_len', default=700, type=int)
    #parser.add_argument('-v_l', '--valid_len', default=300, type=int)
    args = parser.parse_args()

    Dem = DEnsembleModel(
        '/root/other/xtp_data/close.csv',
        '/root/other/xtp_data/open.csv',
        '/root/other/xtp_data/high.csv',
        '/root/other/xtp_data/low.csv',
        '/root/other/xtp_data/volume.csv',
        '/root/other/xtp_data/alpha_train.npy'
    )

    df_next = Dem.test_regression(contract_dict, long=args.long_num)


