import baostock as bs
import pandas as pd
import datetime
import time
import os
def get_new_data(bs, stockid):
    start_date = (datetime.datetime.today()-datetime.timedelta(days=1)).strftime('%Y-%m-%d')
    end_date = (datetime.datetime.today()+datetime.timedelta(days=1)).strftime('%Y-%m-%d')
    rs = bs.query_history_k_data_plus(stockid,
                                      "date,code,open,high,low,close,preclose,volume,amount,adjustflag,turn,tradestatus,pctChg,peTTM,pbMRQ,psTTM,pcfNcfTTM,isST",
                                      start_date=start_date, end_date=end_date,
                                      frequency="d", adjustflag="1")  # frequency="d"取日k线，adjustflag="3"默认不复权, 1后复权，2前复权

    #### 打印结果集 ####
    data_list = []
    while (rs.error_code == '0') & rs.next():
        # 获取一条记录，将记录合并在一起
        data_list.append(rs.get_row_data())
    result = pd.DataFrame(data_list, columns=rs.fields)
    return result

def get_factor_data(bs, stockid):
    start_date = (datetime.datetime.today()-datetime.timedelta(days=120)).strftime('%Y-%m-%d')
    end_date = (datetime.datetime.today()).strftime('%Y-%m-%d')
    rs = bs.query_adjust_factor(code=stockid)

    #### 打印结果集 ####
    data_list = []
    while (rs.error_code == '0') & rs.next():
        # 获取一条记录，将记录合并在一起
        data_list.append(rs.get_row_data())
    if len(data_list)>0:
        result = pd.DataFrame(data_list, columns=rs.fields)
        print(f"last divide date={result.iloc[-1]['dividOperateDate']}")
        return result.iloc[-1]
    else:
        data = pd.Series({'code':stockid,'dividOperateDate':'2015-01-01','foreAdjustFactor':1, 'backAdjustFactor':1, 'adjustFactor':1})
        return pd.DataFrame(data).T

def fetch_data_start():
    lg = bs.login()
    his_data = pd.read_csv('close.csv').drop(columns=['Unnamed: 0'])
    his_data.set_index('date', inplace=True)
    stock_list = list(his_data.columns)
    config_file = 'hs300.txt'
    if os.path.exists(config_file):
        os.remove(config_file)
    with open(config_file, "w") as f:  # 打开文件
        for stock in stock_list:
            stockid = stock.split('.')[1]
            exchange = stock.split('.')[0]
            f.write(f"{stockid},{exchange}\n")
    f.close()
    all_df = pd.DataFrame()
    all_factor_df = pd.DataFrame()
    for stockid in stock_list:
        print(50*'-')
        print(stockid)
        df = get_new_data(bs, stockid)
        all_df = all_df.append(df)
        time.sleep(0.2)
        factor_df = get_factor_data(bs, stockid)
        all_factor_df = all_factor_df.append(factor_df)
        # all_factor_df.set_index('code', inplace=True)
        all_factor_df.to_csv('factor.csv', index=None)
        all_df.to_csv('stock_new.csv')
    #### 登出系统 ####
    bs.logout()

if __name__ == '__main__':
    #### 登陆系统 ####
    fetch_data_start()
