import redis
import json
import os

REDIS = {
    'host': os.getenv('redis.host', '0.0.0.0'),
    'port': os.getenv('redis.port', 6379),
    'password': os.getenv('redis.password', ''),
    'dbid': os.getenv('redis.dbid', 0),
}

class RedisModel(object):
    def __init__(self):
        if not hasattr(RedisModel, 'pool'):
            RedisModel.create_pool()
        self.conn = redis.Redis(
            connection_pool=RedisModel.pool, charset='UTF-8', encoding='UTF-8')

    @staticmethod
    def create_pool():
        RedisModel.pool = redis.ConnectionPool(
            host=REDIS['host'],
            port=REDIS['port'],
            password=REDIS['password'],
            max_connections=1024,
            db=REDIS['dbid'],
            decode_responses=True
        )


redis_client = RedisModel().conn
